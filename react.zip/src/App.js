import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';

import { Header } from './components/Header';
import Home from './pages/Home';
import Favorites from './pages/Favorites';
import Drawer from './pages/Drawer';
import SignIn from './pages/SignIn';
import Registration from './pages/Registration';
import ShowItem from './pages/ShowItem';
import { Footer } from './components/Footer';

import {
  setItems,
  setCurrentItem,
  setShowCurrentItem,
  fetchItems,
  selectShowCurrentItem,
} from './redux/slices/cardSlice';
import {
  fetchFavorites,
  selectFavoritesItems,
  setFavoritesList,
} from './redux/slices/favoritesSlice';
import { selectSearchValue, setSearchValue } from './redux/slices/filterSlice';
import { fetchDrawerItems, setDrawerItems } from './redux/slices/drawerSlice';
import {
  setAuthorized,
  setUserId,
  setToken,
  selectUserId,
  selectAuthorized,
} from './redux/slices/authorizationSlice';
import ExitWindow from './components/ExitWindow';
import { selectModalExit } from './redux/slices/modalWindowsSlice';

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingFavorites, setIsLoadingFavorites] = useState(false);

  const favoritesList = useSelector(selectFavoritesItems);
  const searchValue = useSelector(selectSearchValue);
  const showCurrentItem = useSelector(selectShowCurrentItem);
  const authorized = useSelector(selectAuthorized);
  const authUserId = useSelector(selectUserId);
  const modalExit = useSelector(selectModalExit);
  const dispatch = useDispatch();

  // Получение данных при первом рендере

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('id');
    async function fetchData() {
      setIsLoading(true);
      if (token !== null) {
        dispatch(setAuthorized(true));
        dispatch(setUserId(userId));
        dispatch(setToken(token));

        dispatch(fetchFavorites());

        dispatch(fetchDrawerItems());
      }

      dispatch(fetchItems());

      setIsLoading(false);
    }

    fetchData();
  }, []);

  // Получение данных при вводе в строку поиска

  useEffect(() => {
    async function fetchData() {
      const resultSearch = await axios(
        `https://a83efa66f4148eb5.mokky.dev/items?title=${searchValue}*`,
      );
      dispatch(setItems(resultSearch.data));
    }
    fetchData();
  }, [searchValue]);

  // Добавление или удаление фаворитов

  const onChangeFavorite = async (favorite) => {
    // Проверка есть ли такой пользователь
    const isUser = await axios.get(
      `https://a83efa66f4148eb5.mokky.dev/favorites?user=${authUserId}`,
    );
    // Если нет пользователя в фаворитах
    if (!isUser.data.length) {
      await axios.post('https://a83efa66f4148eb5.mokky.dev/favorites', {
        user: Number(authUserId),
        items: [favorite],
      });
      dispatch(setFavoritesList([favorite]));
    }
    if (favoritesList.some((item) => item.uniqueId === favorite.uniqueId)) {
      const newFavorites = favoritesList.filter((obj) => obj.uniqueId !== favorite.uniqueId);
      dispatch(setFavoritesList(newFavorites));
      const currentId = await axios(
        `https://a83efa66f4148eb5.mokky.dev/favorites?user=${authUserId}`,
      );
      const favoriteUserId = currentId.data[0].id;
      await axios.patch(`https://a83efa66f4148eb5.mokky.dev/favorites/${favoriteUserId}`, {
        items: newFavorites,
      });
    }
    // Если данного товара нет в массиве товаров пользователя
    else {
      dispatch(setFavoritesList([...favoritesList, favorite]));
      const currentId = await axios(
        `https://a83efa66f4148eb5.mokky.dev/favorites?user=${authUserId}`,
      );
      const favoriteUserId = currentId.data[0].id;
      await axios.patch(`https://a83efa66f4148eb5.mokky.dev/favorites/${favoriteUserId}`, {
        items: [...favoritesList, favorite],
      });
    }
  };

  // Добавление или удаление покупок

  const onChangeDrawer = async (item) => {};

  // Запись в стейт поиска

  const onChangeSearchValue = (e) => {
    dispatch(setSearchValue(e.target.value));
  };

  // Отображение карточки

  const onChangeCurrentItem = (uniqueId, title, price, imageUrl, description) => {
    dispatch(setCurrentItem({ uniqueId, title, price, imageUrl, description }));
    dispatch(setShowCurrentItem(true));
  };

  if (isLoading || isLoadingFavorites) return <div></div>;

  return (
    <>
      <Header onChangeSearchValue={onChangeSearchValue} />
      <main className='main'>
        <div className='container'>
          <Routes>
            <Route
              path='/'
              element={
                <Home
                  onChangeFavorite={onChangeFavorite}
                  onChangeCurrentItem={onChangeCurrentItem}
                />
              }
              // errorElement={<ErrorPage/>}
            />
            <Route path='/drawer' element={<Drawer />} />
            <Route
              path='/favorites'
              element={
                <Favorites
                  onChangeFavorite={onChangeFavorite}
                  onChangeCurrentItem={onChangeCurrentItem}
                />
              }
            />
            <Route path='/registration' element={<Registration />} />
            <Route path='/signIn' element={<SignIn />} />
          </Routes>
        </div>
      </main>
      {showCurrentItem ? <ShowItem onChangeDrawer={onChangeDrawer} /> : null}
      {modalExit ? <ExitWindow /> : null}
      {/* {<Footer />} */}
    </>
  );
}

export default App;
