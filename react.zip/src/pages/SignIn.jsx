import axios from 'axios';
import React from 'react';
import { Link, Navigate, useNavigate, redirect } from 'react-router-dom';
import { selectAuthorized, setAuthorized } from '../redux/slices/authorizationSlice';
import { useDispatch, useSelector } from 'react-redux';

function SignIn() {
  const [loginValue, setLoginValue] = React.useState('');
  const [passwordValue, setPasswordValue] = React.useState('');

  const authorized = useSelector(selectAuthorized);

  const dispatch = useDispatch();

  const onChangeLoginValue = (e) => {
    setLoginValue(e.target.value);
  };

  const onChangePasswordValue = (e) => {
    setPasswordValue(e.target.value);
  };

  const onHandleSubmit = async (e) => {
    e.preventDefault();
  };

  const onSendAuth = async () => {
    const auth = await fetch('https://a83efa66f4148eb5.mokky.dev/auth', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: `${loginValue}`,
        password: `${passwordValue}`,
      }),
    }).then((result) => {
      if (result.ok) {
        <Navigate to='/' />;
        return result.json();
      } else {
        alert('Произошла ошибка!');
        return null;
      }
    });
    if (auth !== null) {
      const { token, data } = auth;
      localStorage.setItem('token', token);
      localStorage.setItem('id', data.id);
      localStorage.setItem('fullName', data.fullName);
      dispatch(setAuthorized(true));
    }
  };

  return (
    <>
      <form onSubmit={onHandleSubmit} className='authForm' action=''>
        {/* <div>
        <h2>Вход</h2>
        <Link to='/'>
          <img width={30} height={30} src='./img/close.svg' alt='#' />
        </Link>
      </div> */}
        <div className='field'>
          <input
            type='email'
            name='email'
            placeholder='login'
            onChange={onChangeLoginValue}
            value={loginValue}
          />
        </div>
        <div className='field'>
          <input
            type='password'
            name='password'
            placeholder='password'
            onChange={onChangePasswordValue}
            value={passwordValue}
          />
        </div>
        <input className='authForm-button' type='submit' onClick={onSendAuth} />
        <Link to='/registration'>
          <h3>Регистрация</h3>
        </Link>
      </form>
      {authorized ? <Navigate to='/' /> : null};
    </>
  );
}

export default SignIn;
