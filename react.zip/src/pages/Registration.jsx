import React from 'react';
import { Link } from 'react-router-dom';

function Registration() {
  const [nameValue, setNameValue] = React.useState('');
  const [emailValue, setEmailValue] = React.useState('');
  const [passwordValue, setPasswordValue] = React.useState('');

  const onChangeNameValue = (e) => {
    setNameValue(e.target.value);
  };
  const onChangeEmailValue = (e) => {
    setEmailValue(e.target.value);
  };

  const onChangePasswordValue = (e) => {
    setPasswordValue(e.target.value);
  };

  const onHandleSubmit = async (e) => {
    e.preventDefault();
  };

  const onSendRegister = async () => {
    const auth = await fetch('https://a83efa66f4148eb5.mokky.dev/register', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fullName: `${nameValue}`,
        email: `${emailValue}`,
        password: `${passwordValue}`,
      }),
    }).then((result) => {
      if (result.ok) {
        alert('Регистрация прошла успешно!');

        return result.json();
      }
      alert('Произошла ошибка!');
      return null;
    });

    if (auth !== null) {
      const { token, data } = auth;
      localStorage.setItem('token', token);
    }
  };

  return (
    <form onSubmit={onHandleSubmit} className='authForm' action=''>
      <div className='field'>
        <input type='text' placeholder='name' onChange={onChangeNameValue} value={nameValue} />
      </div>
      <div className='field'>
        <input
          type='email'
          name='email'
          placeholder='email'
          onChange={onChangeEmailValue}
          value={emailValue}
        />
      </div>
      <div className='field'>
        <input
          type='password'
          name='password'
          placeholder='password'
          onChange={onChangePasswordValue}
          value={passwordValue}
        />
      </div>
      <input className='authForm-button' type='submit' onClick={onSendRegister} />
      <Link to='/signIn'>
        <h3>Вы уже зарегистрированы</h3>
      </Link>
    </form>
  );
}

export default Registration;
