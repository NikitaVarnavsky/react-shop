export function Footer() {
  return <div>Footer</div>;
}
